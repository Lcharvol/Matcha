module.exports = {
	postgres: {
		password: 'us6T3KclEL7q0UvLloymFR0pW1B2FVHZ',
	},
	optionGeocoder: {
		apiKey: 'AIzaSyC9NS3pHxPN1tr8P1bh0IlMdqfVbbe-XsA',
	},
	secretSentence: 'figaro',
	secretPasswordMail: 'figaro42',
};
